const flags = [
  {
    country: "China",
    url: "https://upload.wikimedia.org/wikipedia/commons/f/fa/Flag_of_the_People%27s_Republic_of_China.svg"
  },
  {
    country: "Canada",
    url: "https://upload.wikimedia.org/wikipedia/commons/c/cf/Flag_of_Canada.svg"
  },
  {
    country: "South Korea",
    url: "https://upload.wikimedia.org/wikipedia/commons/0/09/Flag_of_South_Korea.svg"
  },
  {
    country: "North Korea",
    url: "https://upload.wikimedia.org/wikipedia/commons/5/51/Flag_of_North_Korea.svg"
  },
  {
    country: "Germany",
    url: "https://upload.wikimedia.org/wikipedia/en/b/ba/Flag_of_Germany.svg"
  },
  {
    country: "United Kingdom",
    url: "https://upload.wikimedia.org/wikipedia/en/a/ae/Flag_of_the_United_Kingdom.svg"
  },
  {
    country: "Japan",
    url: "https://upload.wikimedia.org/wikipedia/en/9/9e/Flag_of_Japan.svg"
  },
  {
    country: "Russia",
    url: "https://upload.wikimedia.org/wikipedia/en/f/f3/Flag_of_Russia.svg"
  },
  {
    country: "Soviet Union (USSR)",
    url: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Flag_of_the_Soviet_Union.svg/1920px-Flag_of_the_Soviet_Union.svg.png"
  },
  {
    country: "Vietnam",
    url: "https://upload.wikimedia.org/wikipedia/commons/2/21/Flag_of_Vietnam.svg"
  },
  {
    country: "South Africa",
    url: "https://upload.wikimedia.org/wikipedia/commons/a/af/Flag_of_South_Africa.svg"
  },
  {
    country: "France",
    url: "https://upload.wikimedia.org/wikipedia/en/c/c3/Flag_of_France.svg"
  }
];

// Show today's flag
const now = new Date();
const dayOfYear = Math.floor((now - new Date(now.getFullYear(), 0, 0)) / 86400000);
const index = dayOfYear % flags.length;
const flag = flags[index];

document.body.style.backgroundImage = `url(${flag.url})`;
document.getElementById("country-name").textContent = flag.country;

// Add a weather div to the page
const weatherBox = document.createElement("div");
weatherBox.id = "weather-box";
weatherBox.textContent = "Loading weather...";
document.body.appendChild(weatherBox);

// Style it (optional if you want separate CSS)
weatherBox.style.position = "absolute";
weatherBox.style.top = "20px";
weatherBox.style.left = "20px";   // moved to top left
weatherBox.style.background = "rgba(0, 0, 0, 0.5)";
weatherBox.style.color = "white";
weatherBox.style.padding = "10px 15px";
weatherBox.style.borderRadius = "8px";
weatherBox.style.fontSize = "16px";
weatherBox.style.fontFamily = "sans-serif";


// Get user location
if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition(
    (position) => {
      const lat = position.coords.latitude;
      const lon = position.coords.longitude;

      // Call Open-Meteo API
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`;

      fetch(url)
        .then((response) => response.json())
        .then((data) => {
          const weather = data.current_weather;
          if (weather) {
            const temp = weather.temperature;
            const code = weather.weathercode;

            const icon = weatherIcon(code);

            weatherBox.textContent = `${icon} ${temp}°C`;
          } else {
            weatherBox.textContent = "No weather data.";
          }
        })
        .catch(() => {
          weatherBox.textContent = "Weather error.";
        });
    },
    () => {
      weatherBox.textContent = "Location blocked.";
    }
  );
} else {
  weatherBox.textContent = "Geolocation not supported.";
}

// Simple icons for weather codes
function weatherIcon(code) {
  if (code === 0) return "☀";
  if (code >= 1 && code <= 3) return "⛅";
  if (code >= 45 && code <= 48) return "🌫";
  if (code >= 51 && code <= 67) return "🌦";
  if (code >= 71 && code <= 77) return "❄";
  if (code >= 80 && code <= 82) return "🌧";
  if (code >= 95) return "⛈";
  return "☁";
}
